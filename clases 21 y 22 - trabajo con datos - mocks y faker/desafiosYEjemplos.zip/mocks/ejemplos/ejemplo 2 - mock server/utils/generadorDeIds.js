let id = 1
export function generarId() {
    return id++
}